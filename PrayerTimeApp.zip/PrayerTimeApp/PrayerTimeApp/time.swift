import Foundation
struct Time {
    
    var timePrayer:String?
    var timeName:String?
//    var timearr:[Datum]=[]
}

var timearr:[Time] = [
//    Time(timePrayer: "4:14AM", timeName: "فجر"),
//    Time(timePrayer: "11:53AM", timeName: "ظهر"),
//    Time(timePrayer: "3:21PM", timeName: "عصر"),
//    Time(timePrayer: "6:11PM", timeName: "مغرب"),
//    Time(timePrayer: "7:41PM", timeName: "عشاء")
        ]
