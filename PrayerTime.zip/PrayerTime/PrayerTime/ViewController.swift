
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var hDateLabel: UILabel!
    @IBOutlet weak var gDateLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    var prayerTime : PrayerData!
    var timesValue = [String]()
    var timesText = ["Fajr","Sunrise","Dhuhr","Asr","Sunset","Maghrib","Isha","Firstthird","Lastthird"]
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.register(UINib.init(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        
        fetchPrayerTime { [weak self] (data) in
            self!.prayerTime = data

            
            DispatchQueue.main.async {
                self!.timesValue = [ self!.prayerTime.data.timings.Fajr,
                 self!.prayerTime.data.timings.Sunrise,
                 self!.prayerTime.data.timings.Dhuhr,
                 self!.prayerTime.data.timings.Asr,
                self!.prayerTime.data.timings.Sunset,
                 self!.prayerTime.data.timings.Maghrib,
                 self!.prayerTime.data.timings.Isha,
                 self!.prayerTime.data.timings.Firstthird,
                 self!.prayerTime.data.timings.Lastthird]
                self!.dayLabel.text = self!.prayerTime.data.date.gregorian.weekday.en
                self!.gDateLabel.text = self!.prayerTime.data.date.gregorian.date
                self!.hDateLabel.text = self!.prayerTime.data.date.hijri.date
                self!.tableView.reloadData()
            }
        }
    }

    
    //
    
    func fetchPrayerTime(completionHandler: @escaping (PrayerData) -> Void) {
        
        let url = URL(string:"http://api.aladhan.com/v1/timingsByCity?city=dammam&country=sa&method=4")!
        let task = URLSession.shared.dataTask(with: url, completionHandler: { (mData, response, error) in
          if let error = error {
            print("Error with fetching films: \(error)")
            return
          }
          
          guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
            print("Error with the response, unexpected status code: \(response)")
            return
          }

            if let MyData = mData{
                do
                {
                let DataDecoding = try JSONDecoder().decode( PrayerData.self, from: MyData)
                self.prayerTime = DataDecoding
                   
                }catch
                {
                    print(error)
                }
                
                completionHandler(self.prayerTime)
        }
        }
            )
        task.resume()
      }

}

extension ViewController : UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.timesValue.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? TableViewCell
        cell?.prayerTextLabel.text = self.timesValue[indexPath.row]
        cell?.prayerValueLabel.text = self.timesText[indexPath.row]
        
        return cell!
    }
    
    
}
