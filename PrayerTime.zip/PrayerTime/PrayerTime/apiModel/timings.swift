

import Foundation

struct Timings : Codable
{
    var Fajr : String
    var Sunrise : String
    var Dhuhr : String
    var Asr : String
    var Sunset : String
    var Maghrib : String
    var Isha : String
    var Imsak : String
    var Midnight : String
    var Firstthird : String
    var Lastthird : String
    
}

struct Date : Codable
{
    var readable : String
    var timestamp : String
    var hijri : Hijri
    var gregorian : Gregorian
    
}
struct Hijri : Codable
{
    var date : String
    var format : String
    var day : String
    var weekday : Weekday
    var month : Month
    var year : String
    var designation : Designation
    var holidays : [String]
}
struct Gregorian : Codable
{
    var date : String
    var format : String
    var day : String
    var weekday : Weekday1
    var month : Month1
    var year : String
    var designation : Designation
    
}
struct Weekday1: Codable
{
    var en : String
  
}
struct Weekday: Codable
{
    var en : String
    var ar : String
}
struct Month1: Codable
{
    var number : Int
    var en : String
   
}
struct Month: Codable
{
    var number : Int
    var en : String
    var ar : String
}
struct  Designation: Codable
{
    var abbreviated : String
    var expanded :String
}
struct Meta: Codable
{
    var latitude : Double
    var longitude : Double
    var timezone : String
    var method : Method
    var latitudeAdjustmentMethod : String
    var midnightMode : String
    var school : String
    var offset : Offset
}

struct Method : Codable
{
    var id : Int
    var name : String
    var params : Params
    var location : Location
    
}

struct Location : Codable
{
    var latitude : Double
    var longitude : Double
}
struct Params : Codable
{
    var Fajr : Double
    var Isha : String
}

struct Data : Codable
{
    var timings : Timings
    var date : Date
    var meta : Meta
  
}

struct Offset : Codable
{
    var Imsak : Int
    var Fajr : Int
    var Sunrise : Int
    var Dhuhr : Int
    var Asr : Int
    var Maghrib : Int
    var Sunset : Int
    var Isha : Int
    var Midnight : Int
}

struct PrayerData :Codable
{
    var code : Int
    var status : String
    var data : Data
}
